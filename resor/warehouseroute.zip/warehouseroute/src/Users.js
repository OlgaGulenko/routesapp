import React, { Component } from 'react';
import './style.css';
import {Navigation} from "./index"

class Users extends Component {
  render() {
    return (

      <div className="container-fluid">
        <Navigation/>
    sadfghjkhgdsadfgtyui
      </div>
    );
  }
}

export default Users;
